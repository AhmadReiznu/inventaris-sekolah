<?php
// Koneksi Ke database
$conn = mysqli_connect("localhost", "root", "", "inventaris");
$cek_data = '';

function query($query){
    global $conn;

    $result = mysqli_query($conn, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

function Jumlah($query) {
    global $conn;

    $result = mysqli_query($conn, $query);
    $result = mysqli_num_rows($result);
    return $result;
}


// Data Petugas
function TambahPetugas($data)
{   
    global $conn;
    global $cek_data;
    
    $username = htmlspecialchars(strtolower(stripslashes($data["username"])));
    $nama = htmlspecialchars($data["nama_petugas"]);
    $email = htmlspecialchars($data["email"]);
    $level = htmlspecialchars($data["id_level"]);
    $password = htmlspecialchars(mysqli_real_escape_string($conn, $data["password"]));
    $konfirmasi = htmlspecialchars(mysqli_real_escape_string($conn, $data["konfirmasi_password"]));

    if ($password != $konfirmasi) {
        echo "<script>
                alert('Password Tidak Sesuai');
            </script>";
        return false;
    }

    // Cek Username Sudah Ada
    $cek_username = mysqli_query($conn, "SELECT username FROM petugas WHERE username = '$username'");
    $cek_email = mysqli_query($conn, "SELECT email FROM petugas WHERE email = '$email'");

    if (mysqli_fetch_assoc($cek_username)) {
        $cek_data = 'Username Sudah Terdaftar';
        return false;
    } else if (mysqli_fetch_assoc($cek_email)) {
        $cek_data = 'Email Sudah Terdaftar';
        return false;
    }

    // Enkripsi Password
    $password = password_hash($password, PASSWORD_DEFAULT);

    // Tambah User
    $query = "INSERT INTO petugas VALUES('', '$username', '$email', '$password', '$nama', '$level')";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function UbahPetugas($data) {
    global $conn, $cek_data;

    $id = $data["id_petugas"];
    $username = htmlspecialchars(strtolower(stripslashes($data["username"])));
    $nama = htmlspecialchars($data["nama_petugas"]);
    $email = htmlspecialchars($data["email"]);
    $level = htmlspecialchars($data["id_level"]);
    $password = htmlspecialchars(mysqli_real_escape_string($conn, $data["password"]));
    $konfirmasi = htmlspecialchars(mysqli_real_escape_string($conn, $data["konfirmasi_password"]));

    if ($password != $konfirmasi) {
        $cek_data = 'Konfirmasi Password Tidak Sesuai';
        return $cek_data;
    }

    // Enkripsi Password
    $password = password_hash($password, PASSWORD_DEFAULT);

    // Tambah User
    $query ="UPDATE petugas SET
                username = '$username', 
                email = '$email',
                password = '$password', 
                nama_petugas = '$nama', 
                id_level = '$level'
            WHERE id_petugas = '$id'";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function HapusPetugas($id) {
    global $conn;

    mysqli_query($conn, "DELETE FROM petugas WHERE id_petugas = '$id'");
    return mysqli_affected_rows($conn);
}
// Akhir Data Petugas 


// Data Inventaris
function TambahInventaris($data) {
    global $conn;
    
    $nama = htmlspecialchars(strtolower(stripslashes($data["nama"])));
    $kondisi = htmlspecialchars($data["kondisi"]);
    $jumlah = htmlspecialchars($data["jumlah_inventaris"]);
    $id_jenis = htmlspecialchars($data["id_jenis"]);
    $tgl_register = htmlspecialchars($data["tgl_register"]);
    $id_ruang = htmlspecialchars($data["id_ruang"]);
    $kode_inventaris = htmlspecialchars($data["kode_inventaris"]);

    // Tambah User
    $query = "INSERT INTO inven_tb VALUES(
        '', '$nama', '$kondisi', '$jumlah',
        '$id_jenis', '$tgl_register',
        '$id_ruang', '$kode_inventaris')";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function UbahInventaris($data) {
    global $conn;
    
    $id = $data["id_inventaris"];
    $nama = htmlspecialchars(strtolower(stripslashes($data["nama"])));
    $kondisi = htmlspecialchars($data["kondisi"]);
    $jumlah = htmlspecialchars($data["jumlah_inventaris"]);
    $id_jenis = htmlspecialchars($data["id_jenis"]);
    $tgl_register = htmlspecialchars($data["tgl_register"]);
    $id_ruang = htmlspecialchars($data["id_ruang"]);
    $kode_inventaris = htmlspecialchars($data["kode_inventaris"]);

    // Tambah User
    $query = "UPDATE inven_tb SET
                nama = '$nama', 
                kondisi = '$kondisi', 
                jumlah_inventaris = '$jumlah', 
                id_jenis = '$id_jenis',
                tgl_register = '$tgl_register',
                id_ruang = '$id_ruang', 
                kode_inventaris = '$kode_inventaris'
            WHERE id_inventaris = '$id'";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function HapusInventaris($id) {
    global $conn;

    mysqli_query($conn, "DELETE FROM inven_tb WHERE id_inventaris = '$id'");
    return mysqli_affected_rows($conn);
}
// Akhir Inventaris


// Data Barang
function TambahBarang($data) {
    global $conn;
    
    $nama_jenis = htmlspecialchars(strtolower(stripslashes($data["nama_jenis"])));
    $kode_jenis = htmlspecialchars($data["kode_jenis"]);
    $keterangan_jenis = htmlspecialchars($data["keterangan_jenis"]);

    // Tambah User
    $query = "INSERT INTO jenis VALUES(
        '', '$nama_jenis', '$kode_jenis', '$keterangan_jenis')";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function UbahBarang($data) {
    global $conn;
    
    $id = $data["id_jenis"];
    $nama_jenis = htmlspecialchars(strtolower(stripslashes($data["nama_jenis"])));
    $kode_jenis = htmlspecialchars($data["kode_jenis"]);
    $keterangan_jenis = htmlspecialchars($data["keterangan_jenis"]);

    // Tambah User
    $query = "UPDATE jenis SET
                nama_jenis = '$nama_jenis', 
                kode_jenis = '$kode_jenis', 
                keterangan_jenis = '$keterangan_jenis'
            WHERE id_jenis = '$id'";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function HapusBarang($id) {
    global $conn;

    mysqli_query($conn, "DELETE FROM jenis WHERE id_jenis = '$id'");
    return mysqli_affected_rows($conn);
}
// Akhir Data Barang


// Data Ruangan
function TambahRuangan($data) {
    global $conn;
    
    $nama_ruang = htmlspecialchars(strtolower(stripslashes($data["nama_ruang"])));
    $kode_ruang = htmlspecialchars($data["kode_ruang"]);
    $keterangan_ruang = htmlspecialchars($data["keterangan_ruang"]);

    // Tambah User
    $query = "INSERT INTO ruang VALUES(
        '', '$nama_ruang', '$kode_ruang', '$keterangan_ruang')";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function UbahRuangan($data) {
    global $conn;
    
    $id = $data["id_ruang"];
    $nama_ruang = htmlspecialchars(strtolower(stripslashes($data["nama_ruang"])));
    $kode_ruang = htmlspecialchars($data["kode_ruang"]);
    $keterangan_ruang = htmlspecialchars($data["keterangan_ruang"]);

    // Tambah User
    $query = "UPDATE ruang SET
                nama_ruang = '$nama_ruang', 
                kode_ruang = '$kode_ruang', 
                keterangan_ruang = '$keterangan_ruang'
            WHERE id_ruang = '$id'";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function HapusRuangan($id) {
    global $conn;

    mysqli_query($conn, "DELETE FROM ruang WHERE id_ruang = '$id'");
    return mysqli_affected_rows($conn);
}
// Akhir Data Ruangan


// Data Pinjam
function TambahDetailPinjam($data){
    global $conn;
    
    $id_inventaris = htmlspecialchars(strtolower(stripslashes($data["id_inventaris"])));
    $jumlah = htmlspecialchars($data["jumlah"]);

    // Tambah Detail Pinjam
    $query = "INSERT INTO detail_pinjam VALUES(
        '', '$id_inventaris', '$jumlah')";
    mysqli_query($conn,$query);
    return mysqli_affected_rows($conn);
}

function TambahPeminjaman($data){
    global $conn;
    
    $id_detail_pinjam = htmlspecialchars(strtolower(stripslashes($data["id_detail_pinjam"])));
    $tgl_peminjaman = htmlspecialchars($data["tgl_peminjaman"]);
    $tgl_kembali = htmlspecialchars($data["tgl_kembali"]);
    $status_peminjaman = htmlspecialchars($data["status_peminjaman"]);
    $id_pegawai = htmlspecialchars($data["id_pegawai"]);

    // Tambah Peminjaman
    $query = "INSERT INTO peminjaman VALUES(
        '', '$id_detail_pinjam', '$tgl_peminjaman', '$tgl_kembali', '$status_peminjaman', '$id_pegawai')";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function UbahPeminjaman($data) {
    global $conn;
    
    $id = $data["id_peminjaman"];
    $id_detail_pinjam = htmlspecialchars(strtolower(stripslashes($data["id_detail_pinjam"])));
    $tgl_peminjaman = htmlspecialchars($data["tgl_peminjaman"]);
    $tgl_kembali = htmlspecialchars($data["tgl_kembali"]);
    $status_peminjaman = htmlspecialchars($data["status_peminjaman"]);
    $id_pegawai = htmlspecialchars($data["id_pegawai"]);

    // Tambah User
    $query = "UPDATE peminjaman SET
                id_detail_pinjam = '$id_detail_pinjam', 
                tgl_peminjaman = '$tgl_peminjaman', 
                tgl_kembali = '$tgl_kembali',
                status_peminjaman = '$status_peminjaman',
                id_pegawai = '$id_pegawai'
            WHERE id_peminjaman = '$id'";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function HapusPeminjaman($id) {
    global $conn;
    query("DELETE FROM detail_pinjam WHERE id_detail_pinjam = '$id'");
    return mysqli_affected_rows($conn);
}
// Akhir Data Pinjam


// Data Pegawai
function TambahPegawai($data) {
    global $conn;

    $nama_pegawai = htmlspecialchars(strtolower(stripslashes($data["nama_pegawai"])));
    $nip = htmlspecialchars($data["nip"]);
    $alamat = htmlspecialchars($data["alamat"]);

    // Tambah Pegawai
    $query = "INSERT INTO pegawai VALUES(
        '', '$nama_pegawai', '$nip', '$alamat')";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function HapusPegawai($id) {
    global $conn;

    mysqli_query($conn, "DELETE FROM pegawai WHERE id_pegawai = '$id'");
    return mysqli_affected_rows($conn);
}

function UbahPegawai($data) {
    global $conn;
    
    $id = $data['id_pegawai'];
    $nama_pegawai = htmlspecialchars(strtolower(stripslashes($data['nama_pegawai'])));
    $nip = htmlspecialchars($data['nip']);
    $alamat = htmlspecialchars($data['alamat']);

    // Ubah Pegawai
    $query = "UPDATE pegawai SET
                nama_pegawai = '$nama_pegawai', 
                nip = '$nip', 
                alamat = '$alamat'
            WHERE id_pegawai = '$id'";
    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}
// Akhir Data Pegawai