<?php 
session_start();
require "../../functions.php";

// Cek Apakah User Sudah Login
if (!isset($_SESSION["login"])) {
    header('Location: ../../index');
}

if ($_SESSION['level'] == 2  or $_SESSION['level'] == 3 ) {
    header('Location: ../home/');
}

$inventaris = query("SELECT * FROM inven_tb INNER JOIN jenis
                        ON inven_tb.id_jenis = jenis.id_jenis INNER JOIN ruang
                        ON inven_tb.id_ruang = ruang.id_ruang INNER JOIN petugas
                        ON inven_tb.id_petugas = petugas.id_petugas");
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title class="title">Inventaris</title>

    <link rel="shortcut icon" href="../assets/images/box.png" type="image/x-icon"/>
    <!-- Custom fonts for this template-->
    <link href="../assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../assets/dist/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="../assets/dist/css/inventaris.css" rel="stylesheet">

    <style>
        @media print {
            .title, .btn {
                display: none;
            } 
        @page {
                size: auto;
                margin: 0;
            }
        }
    </style>

</head>

<body>
<!-- Page Wrapper -->
<div>

    <!-- Content Wrapper -->
    <div>

        <!-- Main Content -->
        <div id="content">

            <!-- Begin Page Content -->
            <div class="container-fluid">
                <!-- Page Heading -->
                <center>
                    <h1 class="h3 mb-2 text-gray-800">Inventaris</h1>
                    <p class="mb-4">Data Inventaris</p>
                </center>
                
                <a href="http://localhost/ukk_inventaris/dashboard/home/" class="btn btn-danger">Kembali</a>
                <!-- DataTales Example -->
                <div>
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary text-center">Tabel Inventaris</h6>
                    </div>
                    <div>
                        <div>
                            <br>
                            <table class="table table-hover text-center" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nama</th>
                                        <th>kondisi</th>
                                        <th>Jumlah</th>
                                        <th>Nama Barang</th>
                                        <th>Tgl Register</th>
                                        <th>Nama Ruang</th>
                                        <th>Kode Inventaris</th>
                                        <th>Petugas</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>Nama</th>
                                        <th>kondisi</th>
                                        <th>Jumlah</th>
                                        <th>Nama Barang</th>
                                        <th>Tgl Register</th>
                                        <th>Nama Ruang</th>
                                        <th>Kode Inventaris</th>
                                        <th>Petugas</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                <?php
                                    $no = 1;
                                    foreach ($inventaris as $row) : ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><?= $row['nama']; ?></td>
                                        <td><?= $row['kondisi']; ?></td> 
                                        <td><?= $row['jumlah']; ?></td>
                                        <td><?= $row['nama_jenis']; ?></td>
                                        <td><?= $row['tgl_register']; ?></td>
                                        <td><?= $row['nama_ruang']; ?></td>
                                        <td><?= $row['kode_inventaris']; ?></td>
                                        <td><?= $row['nama_petugas']; ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            <div>
                                <h3>Keterangan Inventaris:</h3>
                                <?php foreach ($inventaris as $row) : ?>
                                    <h5><?= $row['nama']; ?></h5> <span><?= $row['keterangan']; ?></span><br>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

    </div>
    <!-- End of Content Wrapper -->
</div>

<script>
    window.print();
</script>

</body>

</html>