<?php 
session_start();
require "../../functions.php";

// Cek Apakah User Sudah Login
if (!isset($_SESSION["login"])) {
    header('Location: ../../index');
}

if ($_SESSION['level'] == 2  or $_SESSION['level'] == 3 ) {
    header('Location: ../home/');
}

$petugas = query("SELECT * FROM petugas INNER JOIN level ON petugas.id_level = level.id_level");
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title class="title">Petugas</title>

    <link rel="shortcut icon" href="../assets/images/box.png" type="image/x-icon"/>
    <!-- Custom fonts for this template-->
    <link href="../assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../assets/dist/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="../assets/dist/css/inventaris.css" rel="stylesheet">

    <style>
        @media print {
            .title, .btn {
                display: none;
            } 
        @page {
                size: auto;
                margin: 0;
            }
        }
    </style>

</head>

<body>
<!-- Page Wrapper -->
<div>

    <!-- Content Wrapper -->
    <div>

        <!-- Main Content -->
        <div id="content">

            <!-- Begin Page Content -->
            <div class="container-fluid">
                <!-- Page Heading -->
                <center>
                    <h1 class="h3 mb-2 text-gray-800">Petugas</h1>
                    <p class="mb-4">Data Petugas</p>
                </center>
                
                <a href="http://localhost/ukk_inventaris/dashboard/home/" class="btn btn-danger">Kembali</a>
                <!-- DataTales Example -->
                <div>
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary text-center">Tabel Petugas</h6>
                    </div>
                    <div>
                        <div>
                            <br>
                            <table class="table table-hover text-center" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Username</th>
                                        <th>Nama</th>
                                        <th>Email</th>
                                        <th>Level</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>Username</th>
                                        <th>Nama</th>
                                        <th>Email</th>
                                        <th>Level</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                <?php
                                $no = 1;
                                foreach ($petugas as $row) : ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><?= $row['username']; ?></td> 
                                    <td><?= $row['nama_petugas']; ?></td>
                                    <td><?= $row['email']; ?></td>
                                    <td><?= $row['nama_level']; ?></td>
                                </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

    </div>
    <!-- End of Content Wrapper -->
</div>

<script>
    window.print();
</script>

</body>

</html>