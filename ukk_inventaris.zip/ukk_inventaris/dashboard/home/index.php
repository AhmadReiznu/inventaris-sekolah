<?php 
session_start();
$title = "Dashboard";

include '../template/header.php'; 
require "../../functions.php";

// Cek Apakah User Sudah Login
if (!isset($_SESSION["login"])) {
    header('Location: ../../index');
}

if ($_SESSION['level'] == 2  or $_SESSION['level'] == 3 ) {
    $display = 'd-none';
} else {
    $display = '';
}

$username = $_SESSION["username"];
$petugas = query("SELECT * FROM petugas WHERE username = '$username'")[0];
$jumlah_barang = Jumlah("SELECT * FROM jenis");
$jumlah_petugas = Jumlah("SELECT * FROM petugas");
$jumlah_ruang = Jumlah("SELECT * FROM ruang");
$jumlah_peminjaman = Jumlah("SELECT * FROM peminjaman");
?>

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <?php include '../template/sidebar.php'; ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php include '../template/topBar.php'; ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-gray-800">Selamat Datang Di Dashboard Inventaris</h1>
                </div>

                <!-- Content Row -->
                <div class="row">

                    <!-- Earnings (Monthly) Card Example -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Jumlah Barang</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $jumlah_barang; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-boxes fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Earnings (Monthly) Card Example -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            Petugas</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $jumlah_petugas; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Earnings (Monthly) Card Example -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Jumlah Peminjaman
                                        </div>
                                        <div class="row no-gutters align-items-center">
                                            <div class="col-auto">
                                                <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?= $jumlah_peminjaman ?></div>
                                            </div>
                                            <div class="col">
                                                <div class="progress progress-sm mr-2">
                                                    <div class="progress-bar bg-info" role="progressbar"
                                                        style="width: <?= $jumlah_peminjaman ?>%" aria-valuenow="<?= $jumlah_peminjaman ?>" aria-valuemin="0"
                                                        aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Pending Requests Card Example -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                            Jumlah Ruangan</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $jumlah_ruang; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-chair fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Content Row -->
                <div class="row <?= $display ?>">

                    <!-- Content Column -->
                    <div class="col-lg-3">

                        <!-- Project Card Example -->
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Cetak Laporan</h6>
                            </div>
                            <div class="card-body">
                                <h4 class="small font-weight-bold">Data Barang</h4>
                                <div class="mb-4">
                                    <a href="../cetak/cetakBarang" class="d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Cetak Laporan</a>
                                </div>
                                <h4 class="small font-weight-bold">Data Inventaris</h4>
                                <div class="mb-4">
                                    <a href="../cetak/cetakInventaris" class="d-sm-inline-block btn btn-sm btn-secondary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Cetak Laporan</a>
                                </div>
                                <h4 class="small font-weight-bold">Data Petugas</h4>
                                <div class="mb-4">
                                    <a href="../cetak/cetakPetugas" class="d-sm-inline-block btn btn-sm btn-success shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Cetak Laporan</a>
                                </div>
                                <h4 class="small font-weight-bold">Data Pegawai</h4>
                                <div class="mb-4">
                                    <a href="../cetak/cetakPegawai" class="d-sm-inline-block btn btn-sm btn-dark shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Cetak Laporan</a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->
        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Reiznu Ahmad Tjandrida</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->
<?php include '../template/footer.php'; ?>