<?php 
session_start();
$title = "Profil";

include '../template/header.php';
require "../../functions.php";

// Cek Apakah User Sudah Login
if (!isset($_SESSION["login"])) {
    header('Location: ../../index');
}

if ($_SESSION['level'] == 2  or $_SESSION['level'] == 3 ) {
    $display = 'd-none';
} else {
    $display = '';
}

$username = $_SESSION["username"];
$petugas = query("SELECT * FROM petugas WHERE username = '$username'")[0];
?>

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <?php include '../template/sidebar.php'; ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php include '../template/topBar.php'; ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Profil</h1>
                <p class="mb-4">Profil Akun</p>

                <div class="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <!-- Column -->
                        <div class="col-lg-4 col-xlg-3 col-md-5">
                            <div class="card">
                                <div class="card-body">
                                    <center class="m-t-30"> <img src="../assets/images/users/5.jpg" class="rounded-circle"
                                            width="150" />
                                        <h4 class="card-title m-t-10"><?= $petugas["nama_petugas"]; ?></h4>
                                        <h6 class="card-subtitle"><?= $_SESSION["nama_level"]; ?></h6>
                                    </center>
                                </div>
                                <div>
                                    <hr>
                                </div>
                                <div class="card-body"> <small class="text-muted">Email</small>
                                    <h6><?= $petugas["email"]; ?></h6>
                                </div>
                            </div>
                        </div>
                        <!-- Column -->
                        <!-- Column -->
                        <div class="col-lg-8 col-xlg-9 col-md-7">
                            <div class="card">
                                <div class="card-body">
                                    <form class="form-horizontal form-material">
                                        <div class="form-group">
                                            <label class="col-md-12">Nama</label>
                                            <div class="col-md-12">
                                                <input type="text" value="<?= $petugas["nama_petugas"]; ?>" class="form-control form-control-line" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="example-email" class="col-md-12">Email</label>
                                            <div class="col-md-12">
                                                <input type="email" value="<?= $petugas["email"]; ?>" class="form-control form-control-line" disabled>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-12">Level</label>
                                            <div class="col-sm-12">
                                                <input type="email" value="<?= $_SESSION["nama_level"]; ?>" class="form-control form-control-line" disabled>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="form-group <?= $display?>">
                                            <div class="col-sm-12">
                                                <a href="../petugas/ubah.php?id=<?= $petugas['id_petugas']?>" class="btn btn-success border-0">Ubah</a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- Column -->
                    </div>
                </div>
        </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Reiznu Ahmad Tjandrida</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->
<?php include '../template/footer.php'; ?>