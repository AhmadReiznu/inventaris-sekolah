<?php 
session_start();
$title = "Ruangan";

include '../template/header.php'; 
require "../../functions.php";

// Cek Apakah User Sudah Login
if (!isset($_SESSION["login"])) {
    header('Location: ../../index');
}

if ($_SESSION['level'] == 2  or $_SESSION['level'] == 3 ) {
    header('Location: ../home/');
}

$ruangan = query("SELECT * FROM ruang");
?>





<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <?php include '../template/sidebar.php'; ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php include '../template/topBar.php'; ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Ruangan</h1>
                <p class="mb-4">Data Ruangan</p>

                <!-- DataTales Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Tabel Ruangan</h6>
                        <span>*note: Menghapus Data Ruangan, Otomatis Akan Menghapus Data Inventaris Juga.</span>
                    </div>
                    <div class="card-body">
                        <?php if (isset($_SESSION["sukses"])) : ?>
                                <div class="alert alert-success" role="alert">Data Berhasil Ditambahkan</div>
                                <?php unset($_SESSION["sukses"]);?>
                        <?php endif;?>
                        <?php if (isset($_SESSION["ubah"])) : ?>
                                <div class="alert alert-success" role="alert">Data Berhasil Di Ubah</div>
                                <?php unset($_SESSION["ubah"]);?>
                        <?php endif;?>
                        <?php if (isset($_SESSION["hapus"])) : ?>
                                <div class="alert alert-success" role="alert">Data Berhasil Di Hapus</div>
                                <?php unset($_SESSION["hapus"]);?>
                        <?php endif;?>
                        <a href="tambah_ruang">
                            <button class="btn btn-success">Tambah Ruangan</button>
                        </a>
                        </h6>
                        <div class="table-responsive">
                            <br>
                            <table class="table table-hover" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nama Ruangan</th>
                                        <th>Kode Ruangan</th>
                                        <th>Keterangan Ruangan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>Nama Ruangan</th>
                                        <th>Kode Ruangan</th>
                                        <th>Keterangan Ruangan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php
                                        $no = 1;
                                        foreach ($ruangan as $row) : ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><?= $row['nama_ruang']; ?></td>
                                        <td><?= $row['kode_ruang']; ?></td> 
                                        <td><?= $row['keterangan_ruang']; ?></td>
                                        <td>
                                            <a href="ubah_ruang.php?id=<?= $row['id_ruang']; ?>" class="btn btn-success">
                                                <img src="../assets/images/pencil.png" width="20px">
                                            </a>
                                            <a href="hapus_ruang.php?id=<?= $row['id_ruang']; ?>"  class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data <?= $row['nama_ruang']; ?> ?')">
                                                <img src="../assets/images/delete.png" width="20px">
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Reiznu Ahmad Tjandrida</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->
<?php include '../template/footer.php'; ?>
