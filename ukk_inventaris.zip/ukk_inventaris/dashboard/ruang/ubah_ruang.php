<?php
session_start();
$title = "Ubah Inventaris";

require "../../functions.php";
include '../template/header.php';

// Cek Apakah User Sudah Login
if (!isset($_SESSION["login"])) {
    header('Location: ../../index');
}

if ($_SESSION['level'] == 2  or $_SESSION['level'] == 3 ) {
    header('Location: ../home/');
}

if (isset($_POST["ubah"])) {
    if (UbahRuangan($_POST) > 0) {
        $_SESSION['ubah'] = true;
        header("Location: index");
    } else {
        $gagal = true;
    }
}

$id = $_GET['id'];
$ruangan = query("SELECT * FROM ruang WHERE id_ruang = '$id'")[0];
?>

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <?php include '../template/sidebar.php'; ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php include '../template/topBar.php'; ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Ruangan</h1>
                <p class="mb-4">Ubah Data</p>

                <div class="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <!-- Column -->
                        <div class="col-lg-4 col-xlg-3 col-md-5">
                            <div class="card">
                                <div class="card-body">
                                    <center class="m-t-30"> <img src="../assets/images/users/5.jpg" class="rounded-circle"
                                            width="150" />
                                        <h4 class="card-title m-t-10">Ubah Data</h4>
                                        <h6 class="card-subtitle">Ruangan</h6>
                                    </center>
                                </div>
                            </div>
                        </div>
                        <!-- Column -->
                        <!-- Column -->
                        <div class="col-lg-8 col-xlg-9 col-md-7">
                            <div class="card">
                                <div class="card-body">
                                    <form class="form-horizontal form-material" action="" method="post">
                                        <?php if (isset($gagal)) : ?>
                                            <div class="alert alert-danger" role="alert">
                                                Data Gagal Di Ubah
                                            </div>
                                        <?php endif;?>
                                        <div class="form-group">
                                            <input type="hidden" name="id_ruang" value="<?= $ruangan["id_ruang"]; ?>">

                                            <label class="col-md-12" for="nama_ruang">Nama ruang</label>
                                            <div class="col-md-12">
                                                <input type="text" value="<?= $ruangan["nama_ruang"]; ?>" class="form-control form-control-line" id="nama_ruang" name="nama_ruang" required autofocus>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" for="kode_ruang">Kode ruang</label>
                                            <div class="col-md-12">
                                                <input type="number" value="<?= $ruangan["kode_ruang"]; ?>" class="form-control form-control-line" id="kode_ruang" name="kode_ruang" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="keterangan_ruang" class="col-md-12">Keterangan</label>
                                            <div class="col-md-12">
                                                <textarea name="keterangan_ruang" id="keterangan_ruang" cols="30" rows="10" class="form-control form-control-line"><?= $ruangan["keterangan_ruang"]; ?></textarea>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <button type="submit" class="btn btn-success border-0 px-5" name="ubah">Ubah</button>
                                                <a href="index" class="btn btn-danger border-0">Batal</a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- Column -->
                    </div>
                </div>
        </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Reiznu Ahmad Tjandrida</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->
<?php include '../template/footer.php'; ?>