<?php
session_start();
require '../../functions.php';

// Cek Apakah User Sudah Login
if (!isset($_SESSION["login"])) {
    header('Location: ../../index');
}

if ($_SESSION['level'] == 2  or $_SESSION['level'] == 3 ) {
    header('Location: ../home/');
}

$id = $_GET['id'];
if (HapusRuangan($id) > 0) {
        $_SESSION['hapus'] = true;
        header('Location: index');
} else {
    $gagal = true;
}


?>