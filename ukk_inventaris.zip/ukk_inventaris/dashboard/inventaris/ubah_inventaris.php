<?php
session_start();
$title = "Ubah Inventaris";

require "../../functions.php";
include '../template/header.php';

// Cek Apakah User Sudah Login
if (!isset($_SESSION["login"])) {
    header('Location: ../../index');
}

if (isset($_POST["ubah"])) {
    if (UbahInventaris($_POST) > 0) {
        $_SESSION['ubah'] = true;
        header("Location: index");
    } else {
        $gagal = true;
    }
}

$id = $_GET['id'];
$inventaris = query("SELECT * FROM inven_tb WHERE id_inventaris = '$id'")[0];
$jenis = query("SELECT * FROM jenis");
$ruang = query("SELECT * FROM ruang");
$petugas = query("SELECT * FROM petugas");
?>

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <?php include '../template/sidebar.php'; ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php include '../template/topBar.php'; ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Inventaris</h1>
                <p class="mb-4">Ubah Data</p>

                <div class="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <!-- Column -->
                        <div class="col-lg-4 col-xlg-3 col-md-5">
                            <div class="card">
                                <div class="card-body">
                                    <center class="m-t-30"> <img src="../assets/images/users/5.jpg" class="rounded-circle"
                                            width="150" />
                                        <h4 class="card-title m-t-10">Ubah Data</h4>
                                        <h6 class="card-subtitle">Inventaris</h6>
                                    </center>
                                </div>
                            </div>
                        </div>
                        <!-- Column -->
                        <!-- Column -->
                        <div class="col-lg-8 col-xlg-9 col-md-7">
                            <div class="card">
                                <div class="card-body">
                                    <form class="form-horizontal form-material" action="" method="post">
                                        <?php if (isset($gagal)) : ?>
                                            <div class="alert alert-danger" role="alert">
                                                Data Gagal Di Ubah
                                            </div>
                                        <?php endif;?>
                                        <div class="form-group">
                                            <input type="hidden" name="id_inventaris" value="<?= $inventaris["id_inventaris"]; ?>">

                                            <label class="col-md-12" for="nama">Nama</label>
                                            <div class="col-md-12">
                                                <input type="text" value="<?= $inventaris["nama"]; ?>" class="form-control form-control-line" id="nama" name="nama" required autofocus>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" for="kondisi">Kondisi</label>
                                            <div class="col-md-12">
                                                <input type="text" value="<?= $inventaris["kondisi"]; ?>" class="form-control form-control-line" id="kondisi" name="kondisi" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" for="jumlah_inventaris">Jumlah</label>
                                            <div class="col-md-12">
                                                <input type="number" value="<?= $inventaris["jumlah_inventaris"]; ?>" class="form-control form-control-line" name="jumlah_inventaris" id="jumlah_inventaris" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-12" for="id_jenis">Pilih Barang</label>
                                            <div class="col-sm-12">
                                                <select class="form-control form-control-line" name="id_jenis" id="id_jenis" required>
                                                    <option value="<?= $inventaris["id_jenis"]; ?>">Id Barang Saat Ini : <?= $inventaris["id_jenis"]; ?></option>
                                                    <?php foreach ($jenis as $row) : ?>
                                                        <option value="<?= $row['id_jenis']?>">
                                                            <?= $row['id_jenis']?> : <?= $row['nama_jenis']?>
                                                        </option>
                                                    <?php endforeach;?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" for="tgl_register">Tanggal Register</label>
                                            <div class="col-md-12">
                                                <input type="date" value="<?= $inventaris["tgl_register"]; ?>" class="form-control form-control-line" name="tgl_register" id="konfirmasi_password" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-12" for="id_ruang">Ruangan</label>
                                            <div class="col-sm-12">
                                                <select class="form-control form-control-line" name="id_ruang" id="id_ruang" required>
                                                    <option value="<?= $inventaris["id_ruang"]; ?>">Id Ruang Saat Ini : <?= $inventaris["id_ruang"]; ?></option>
                                                    <?php foreach ($ruang as $row) : ?>
                                                        <option value="<?= $row['id_ruang']?>">
                                                        <?= $row['id_ruang']?> : <?= $row['nama_ruang']?></option>
                                                    <?php endforeach;?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" for="kode_inventaris">Kode Inventaris</label>
                                            <div class="col-md-12">
                                                <input type="number" value="<?= $inventaris["kode_inventaris"]; ?>" min="8" class="form-control form-control-line" name="kode_inventaris" id="kode_inventaris" required>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <button type="submit" class="btn btn-success border-0 px-5" name="ubah">Ubah</button>
                                                <a href="index" class="btn btn-danger border-0">Batal</a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- Column -->
                    </div>
                </div>
        </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Reiznu Ahmad Tjandrida</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->
<?php include '../template/footer.php'; ?>