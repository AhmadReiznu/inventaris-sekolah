<?php
session_start();
require '../../functions.php';

// Cek Apakah User Sudah Login
if (!isset($_SESSION["login"])) {
    header('Location: ../../index');
}

$id = $_GET['id'];
if (HapusPeminjaman($id) > 0) {
        $_SESSION['hapus'] = true;
        header('Location: index');
} else {
    $gagal = true;
}
?>