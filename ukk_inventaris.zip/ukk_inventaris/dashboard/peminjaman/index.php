<?php 
session_start();
$title = "Peminjaman";

include '../template/header.php'; 
require "../../functions.php";

// Cek Apakah User Sudah Login
if (!isset($_SESSION["login"])) {
    header('Location: ../../index');
}

$peminjaman = query("SELECT * FROM peminjaman INNER JOIN detail_pinjam
                        ON peminjaman.id_detail_pinjam = detail_pinjam.id_detail_pinjam INNER JOIN pegawai
                        ON peminjaman.id_pegawai = pegawai.id_pegawai INNER JOIN inven_tb
                        ON detail_pinjam.id_inventaris = inven_tb.id_inventaris INNER JOIN jenis
                        ON inven_tb.id_jenis = jenis.id_jenis");
?>

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <?php include '../template/sidebar.php'; ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php include '../template/topBar.php'; ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Peminjaman</h1>
                <p class="mb-4">Data Peminjaman</p>

                <!-- DataTales Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Tabel Peminjaman</h6>
                    </div>
                    <div class="card-body">
                        <?php if (isset($_SESSION["sukses"])) : ?>
                                <div class="alert alert-success" role="alert">Data Berhasil Di Tambahkan</div>
                                <?php unset($_SESSION["sukses"]);?>
                        <?php endif;?>
                        <?php if (isset($_SESSION["ubah"])) : ?>
                                <div class="alert alert-success" role="alert">Data Berhasil Di Ubah</div>
                                <?php unset($_SESSION["ubah"]);?>
                        <?php endif;?>
                        <?php if (isset($_SESSION["hapus"])) : ?>
                                <div class="alert alert-success" role="alert">Data Berhasil Di Hapus</div>
                                <?php unset($_SESSION["hapus"]);?>
                        <?php endif;?>
                        <a href="tambah_peminjaman">
                            <button class="btn btn-success">Tambah Peminjaman</button>
                        </a>
                        </h6>
                        <div class="table-responsive">
                            <br>
                            <table class="table table-hover" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nama Barang</th>
                                        <th>Jenis Barang</th>
                                        <th>Jumlah</th>
                                        <th>tanggal Pinjam</th>
                                        <th>Tanggal Kembali</th>
                                        <th>Status Peminjaman</th>
                                        <th>Nama Pegawai</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>Nama Barang</th>
                                        <th>Jenis Barang</th>
                                        <th>Jumlah</th>
                                        <th>Tanggal Pinjam</th>
                                        <th>Tanggal Kembali</th>
                                        <th>Status Peminjaman</th>
                                        <th>Nama Pegawai</th>
                                        <th>Aksi</th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php
                                        $no = 1;
                                        foreach ($peminjaman as $row) : ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><?= $row['nama']; ?></td>
                                        <td><?= $row['nama_jenis']; ?></td>
                                        <td><?= $row['jumlah']; ?></td>
                                        <td><?= $row['tgl_peminjaman']; ?></td>
                                        <td><?= $row['tgl_kembali']; ?></td>
                                        <td><?= $row['status_peminjaman']; ?></td>
                                        <td><?= $row['nama_pegawai']; ?></td>
                                        <td>
                                            <a href="ubah_peminjaman?id=<?= $row['id_peminjaman']; ?>" class="btn btn-success">
                                                <img src="../assets/images/pencil.png" width="20px">
                                            </a>
                                            <a href="hapus_peminjaman.php?id=<?= $row['id_detail_pinjam']; ?>" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data <?= $row['nama']; ?> ?')">
                                                <img src="../assets/images/delete.png" width="20px">
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Reiznu Ahmad Tjandrida</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->
<?php include '../template/footer.php'; ?>