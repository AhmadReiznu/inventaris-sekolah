<?php
session_start();
$title = "Ubah Peminjaman";

require "../../functions.php";
include '../template/header.php';

// Cek Apakah User Sudah Login
if (!isset($_SESSION["login"])) {
    header('Location: ../../index');
}

if ($_SESSION['level'] == 3 ) {
    $disable = 'disabled';
} else {
    $disable = '';
}

if (isset($_POST["ubah"])) {
    if (UbahPeminjaman($_POST) > 0) {
        $_SESSION['ubah'] = true;
        header("Location: index");
    } else {
        $gagal = true;
    }
}

$id = $_GET['id'];
$page = $_SERVER['PHP_SELF'];
$sec = "2";

$peminjaman = query("SELECT * FROM peminjaman WHERE id_peminjaman = '$id'")[0];
$detail_pinjam = query("SELECT * FROM detail_pinjam INNER JOIN inven_tb
                        ON detail_pinjam.id_inventaris=inven_tb.id_inventaris");
$pegawai = query("SELECT * FROM pegawai");
?>

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <?php include '../template/sidebar.php'; ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php include '../template/topBar.php'; ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Peminjaman</h1>
                <p class="mb-4">Ubah Data</p>

                <div class="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <!-- Detail Pinjam -->
                        <div class="col-lg-4 col-xlg-3 col-md-5">
                            <div class="card">
                                <div class="card-body">
                                    <center class="m-t-30"> <img src="../assets/images/users/5.jpg" class="rounded-circle"
                                            width="150" />
                                        <h4 class="card-title m-t-10">Ubah Data</h4>
                                        <h6 class="card-subtitle">Peminjaman</h6>
                                    </center>
                                </div>
                            </div>
                        </div>
                        <!-- Akhir Detail Pinjam -->

                        <!-- Peminjaman -->
                        <div class="col-lg-8 col-xlg-9 col-md-7">
                            <div class="card">
                                <div class="card-body">
                                    <form class="form-horizontal form-material" action="" method="post">
                                        <?php if (isset($gagal)) : ?>
                                            <div class="alert alert-danger" role="alert">
                                                Data Gagal Di Ubah
                                            </div>
                                        <?php endif;?>
                                        <div class="form-group">
                                            <input type="hidden" name="id_peminjaman" value=<?= $peminjaman['id_peminjaman'] ?>>
                                            <label class="col-md-12" for="id_detail_pinjam">Barang</label>
                                            <div class="col-md-12">
                                                <select class="form-control form-control-line" name="id_detail_pinjam" id="id_detail_pinjam" required>
                                                    <option value="<?= $peminjaman['id_detail_pinjam'] ?>">
                                                            ID Barang Saat Ini: <?= $peminjaman['id_detail_pinjam']?>
                                                    </option>
                                                    <?php foreach ($detail_pinjam as $row ) : ?>
                                                        <option value="<?= $row['id_detail_pinjam'] ?>">
                                                            <?= $row['id_detail_pinjam'] ?> : <?= $row['nama']?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" for="tgl_peminjaman">Tanggal Peminjaman</label>
                                            <div class="col-md-12">
                                                <input type="date" value="<?= $peminjaman["tgl_peminjaman"]; ?>" class="form-control form-control-line" id="tgl_peminjaman" name="tgl_peminjaman" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" for="tgl_kembali">Tanggal Kembali</label>
                                            <div class="col-md-12">
                                                <input type="date" value="<?= $peminjaman["tgl_kembali"]; ?>" class="form-control form-control-line" id="tgl_kembali" name="tgl_kembali" required <?= $disable ?>>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" for="status_peminjaman">Status Peminjaman</label>
                                            <div class="col-md-12">
                                                <select class="form-control form-control-line" name="status_peminjaman" id="status_peminjaman" <?= $disable ?>>
                                                    <option value="Dalam Peminjaman">Dalam Peminjaman</option>
                                                    <option value="Tidak Dipinjam">Tidak Dipinjam</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-12" for="id_pegawai">Pegawai</label>
                                            <div class="col-sm-12">
                                                <select class="form-control form-control-line" name="id_pegawai" id="id_pegawai" required>
                                                    <option value="<?= $peminjaman['id_pegawai']; ?>">
                                                        ID Pegawai Saat Ini : <?= $peminjaman['id_pegawai']; ?>
                                                    </option>
                                                    <?php foreach ($pegawai as $row ) : ?>
                                                        <option value="<?= $row['id_pegawai']; ?>">
                                                            <?= $row['id_pegawai']; ?> : <?= $row['nama_pegawai']; ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <button type="submit" class="btn btn-success border-0 px-5" name="ubah">Ubah</button>
                                                <a href="index" class="btn btn-danger border-0">Batal</a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- Akhir Peminjaman -->
                    </div>
                </div>
        </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Reiznu Ahmad Tjandrida</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->
<?php include '../template/footer.php'; ?>