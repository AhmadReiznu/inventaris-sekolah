<?php
session_start();
$title = "Pinjam Barang";

require "../../functions.php";
include '../template/header.php';

// Cek Apakah User Sudah Login
if (!isset($_SESSION["login"])) {
    header('Location: ../../index');
}

$page = $_SERVER['PHP_SELF'];
$sec = "2";
$inventaris = query("SELECT * FROM inven_tb");
$detail_pinjam = query("SELECT * FROM detail_pinjam INNER JOIN inven_tb
                        ON detail_pinjam.id_inventaris=inven_tb.id_inventaris");
$pegawai = query("SELECT * FROM pegawai");

// Tambah Detail Pinjam
if (isset($_POST["tambah_detail_pinjam"])) {
    if (TambahDetailPinjam($_POST) > 0) {

        $id_inventaris = $_POST['id_inventaris'];
        $jumlah = $_POST['jumlah'];
        $stok = query("SELECT * FROM inven_tb WHERE id_inventaris = '$id_inventaris'")[0];
        $jumlah_inven = $stok['jumlah_inventaris'];

        if ($jumlah > $jumlah_inven) {
            $gagal_stok = true;
        } else {
            $sisa = $jumlah_inven - $jumlah;
            mysqli_query($conn, "UPDATE inven_tb SET jumlah_inventaris = '$sisa' WHERE id_inventaris = '$id_inventaris'");
        }

        $sukses = true;
        header("Refresh: $sec; url=$page");
    } else {
        echo mysqli_error($conn);
    }
}

// Tambah Pinjam
if (isset($_POST["tambah"])) {
    if (TambahPeminjaman($_POST) > 0) {
        $_SESSION['sukses'] = true;
        header('Location: index');
    } else {
        $gagal = true;
    }
}
?>

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <?php include '../template/sidebar.php'; ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php include '../template/topBar.php'; ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">
                <!-- Detail Pinjam -->
                <h1 class="h3 mb-2 text-gray-800">Peminjaman</h1>
                <p class="mb-4">Pinjam Barang</p>
                <?php if (isset($gagal)) : ?>
                        <div class="alert alert-danger" role="alert">
                            Data Gagal Ditambahkan
                        </div>
                <?php endif;?>
                <?php if (isset($gagal_stok)) : ?>
                        <div class="alert alert-danger" role="alert">
                            Peminjaman Melebihi Stok
                        </div>
                <?php endif;?>

                <div class="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <!-- Column -->
                        <!-- Detail Pinjam -->
                        <div class="col-lg-4 col-xlg-3 col-md-5">
                            <div class="card">
                                <div class="card-body">
                                    <form class="form-horizontal form-material" action="" method="post">
                                    <?php if (isset($sukses)) : ?>
                                            <div class="alert alert-success" role="alert">
                                                Data Berhasil Di Tambahkan
                                            </div>
                                    <?php endif;?>
                                        <div class="form-group">
                                            <label class="col-md-12" for="id_inventaris">Detail Pinjam</label>
                                            <div class="col-md-12">
                                                <select class="form-control form-control-line" name="id_inventaris" id="id_inventaris" required>
                                                    <?php foreach ($inventaris as $row ) : ?>
                                                        <option value="<?= $row['id_inventaris'] ?>">
                                                            <?= $row['nama'] ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" for="jumlah">Jumlah Barang Yang Dipinjam</label>
                                            <div class="col-md-12">
                                                <input type="number" placeholder="Maksimal 1 Barang" max="1" class="form-control form-control-line" id="jumlah" name="jumlah" required>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <button type="submit" class="btn btn-success border-0 px-5" name="tambah_detail_pinjam">Tambah</button>
                                                <button type="reset" class="btn btn-danger">Reset</button>
                                            </div>
                                        </div>
                                    </form>
                                    <!-- Akhir Detail Pinjam -->
                                </div>
                            </div>
                        </div>
                        <!-- Akhir Detail Pinjam -->

                        <!-- Column -->
                        <div class="col-lg-8 col-xlg-9 col-md-7">
                            <div class="card">
                                <div class="card-body">
                                    <form class="form-horizontal form-material" action="" method="post">
                                        <div class="form-group">
                                            <label class="col-md-12" for="id_detail_pinjam">Barang</label>
                                            <div class="col-md-12">
                                                <select class="form-control form-control-line" name="id_detail_pinjam" id="id_detail_pinjam" required>
                                                    <?php foreach ($detail_pinjam as $row ) : ?>
                                                        <option value="<?= $row['id_detail_pinjam'] ?>">
                                                            <?= $row['nama']?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" name="tgl_peminjaman">Tanggal Peminjaman</label>
                                            <div class="col-md-12">
                                                <input type="date" class="form-control form-control-line" id="tgl_peminjaman" name="tgl_peminjaman" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" name="tgl_kembali">Tanggal Kembali</label>
                                            <div class="col-md-12">
                                                <input type="date" class="form-control form-control-line" id="tgl_kembali" name="tgl_kembali" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" for="status_peminjaman">Status Peminjaman</label>
                                            <div class="col-md-12">
                                                <select class="form-control form-control-line" name="status_peminjaman" id="status_peminjaman">
                                                    <option value="Dalam Peminjaman" selected>Dalam Peminjaman</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-12" for="id_pegawai">Pegawai</label>
                                            <div class="col-sm-12">
                                                <select class="form-control form-control-line" name="id_pegawai" id="id_pegawai" required>
                                                    <?php foreach ($pegawai as $row ) : ?>
                                                        <option value="<?= $row['id_pegawai']; ?>"><?= $row['nama_pegawai']; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <button type="submit" class="btn btn-success border-0 px-5" name="tambah">Tambah</button>
                                                <a href="index" class="btn btn-danger border-0">Batal</a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- Column -->
                    </div>
                </div>
        </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Reiznu Ahmad Tjandrida</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->
<?php include '../template/footer.php'; ?>