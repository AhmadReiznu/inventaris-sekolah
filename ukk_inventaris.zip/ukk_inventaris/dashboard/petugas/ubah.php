<?php 
session_start();
$title = "Ubah Petugas";

include '../template/header.php';
require "../../functions.php";

// Cek Apakah User Sudah Login
if (!isset($_SESSION["login"])) {
    header('Location: ../../index');
}

if ($_SESSION['level'] == 2  or $_SESSION['level'] == 3 ) {
    header('Location: ../home/');
}

$id = $_GET['id'];
$petugas = query("SELECT * FROM petugas WHERE id_petugas = '$id'")[0];

if (isset($_POST["ubah"])) {
    if (UbahPetugas($_POST) > 0) {
        $_SESSION['ubah'] = true;
        header("Location: index");
    } else {
        $gagal = true;
    }
}
?>

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <?php include '../template/sidebar.php'; ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php include '../template/topBar.php'; ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Petugas</h1>
                <p class="mb-4">Ubah Data</p>

                <div class="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <!-- Column -->
                        <div class="col-lg-4 col-xlg-3 col-md-5">
                            <div class="card">
                                <div class="card-body">
                                    <center class="m-t-30"> <img src="../assets/images/users/5.jpg" class="rounded-circle"
                                            width="150" />
                                        <h4 class="card-title m-t-10"><?= $petugas["nama_petugas"]; ?></h4>
                                        <h6 class="card-subtitle"><?= $_SESSION["nama_level"]; ?></h6>
                                    </center>
                                </div>
                                <div>
                                    <hr>
                                </div>
                                <div class="card-body"> <small class="text-muted">Email</small>
                                    <h6><?= $petugas["email"]; ?></h6>
                                </div>
                            </div>
                        </div>
                        <!-- Column -->
                        <!-- Column -->
                        <div class="col-lg-8 col-xlg-9 col-md-7">
                            <div class="card">
                                <div class="card-body">
                                    <form class="form-horizontal form-material" action="" method="post">
                                    <?php if (isset($gagal)) : ?>
                                            <div class="alert alert-danger" role="alert">
                                                Data Gagal Di Ubah - <?= $cek_data?>
                                            </div>
                                    <?php endif;?>
                                        <div class="form-group">
                                            <input type="hidden" name="id_petugas" value="<?= $petugas["id_petugas"]; ?>">

                                            <label class="col-md-12" for="nama">Nama</label>
                                            <div class="col-md-12">
                                                <input type="text" value="<?= $petugas["nama_petugas"]; ?>" class="form-control form-control-line" id="nama" name="nama_petugas">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" for="username">Username</label>
                                            <div class="col-md-12">
                                                <input type="text" value="<?= $petugas["username"]; ?>" class="form-control form-control-line" id="username" name="username">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="email" class="col-md-12">Email</label>
                                            <div class="col-md-12">
                                                <input type="email" value="<?= $petugas["email"]; ?>" class="form-control form-control-line" name="email" id="email">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" for="password">Password</label>
                                            <div class="col-md-12">
                                                <input type="password" value="<?= $petugas["password"]; ?>" class="form-control form-control-line" name="password" id="password">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" for="konfirmasi_password">Konfirmasi Password</label>
                                            <div class="col-md-12">
                                                <input type="password" placeholder="Konfirmasi Password" class="form-control form-control-line" name="konfirmasi_password" id="konfirmasi_password">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-12" for="id_level">Select Level</label>
                                            <div class="col-sm-12">
                                                <select class="form-control form-control-line" name="id_level" id="id_level">
                                                    <option value="<?= $petugas["id_level"]; ?>">Level Saat Ini: <?= $petugas["id_level"]; ?></option>
                                                    <option value="1">1: Administrator</option>
                                                    <option value="2">2: Operator</option>
                                                    <option value="3">3: Peminjam</option>
                                                </select>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <button type="submit" class="btn btn-success border-0 px-5" name="ubah">Ubah</button>
                                                <a href="index" class="btn btn-danger border-0">Batal</a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- Column -->
                    </div>
                </div>
        </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Reiznu Ahmad Tjandrida</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->
<?php include '../template/footer.php'; ?>