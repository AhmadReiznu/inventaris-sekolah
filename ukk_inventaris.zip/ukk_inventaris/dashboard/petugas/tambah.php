<?php
session_start();
$title = "Tambah Petugas";

require "../../functions.php";
include '../template/header.php';

// Cek Apakah User Sudah Login
if (!isset($_SESSION["login"])) {
    header('Location: ../../index');
}

if ($_SESSION['level'] == 2  or $_SESSION['level'] == 3 ) {
    header('Location: ../home/');
}

if (isset($_POST["tambah"])) {
    if (TambahPetugas($_POST) > 0) {
        $_SESSION['sukses'] = true;
        header("Location: index");
    } else {
        $gagal = true;
    }
}
?>

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <?php include '../template/sidebar.php'; ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <?php include '../template/topBar.php'; ?>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Petugas</h1>
                <p class="mb-4">Tambah Data</p>

                <div class="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <!-- Column -->
                        <div class="col-lg-4 col-xlg-3 col-md-5">
                            <div class="card">
                                <div class="card-body">
                                    <center class="m-t-30"> <img src="../assets/images/users/5.jpg" class="rounded-circle"
                                            width="150" />
                                        <h4 class="card-title m-t-10">Tambah Data</h4>
                                        <h6 class="card-subtitle">Petugas</h6>
                                    </center>
                                </div>
                            </div>
                        </div>
                        <!-- Column -->
                        <!-- Column -->
                        <div class="col-lg-8 col-xlg-9 col-md-7">
                            <div class="card">
                                <div class="card-body">
                                    <form class="form-horizontal form-material" action="" method="post">
                                    <?php if (isset($gagal)) : ?>
                                            <div class="alert alert-danger" role="alert">
                                                Data Gagal Ditambahkan <br> <?= $cek_data; ?>
                                            </div>
                                    <?php endif;?>
                                        <div class="form-group">
                                            <label class="col-md-12" for="nama_petugas">Nama</label>
                                            <div class="col-md-12">
                                                <input type="text" placeholder="Nama Lengkap" class="form-control form-control-line" id="nama_petugas" name="nama_petugas" required autofocus>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" for="username">Username</label>
                                            <div class="col-md-12">
                                                <input type="text" placeholder="Username" class="form-control form-control-line" id="username" name="username" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="email" class="col-md-12">Email</label>
                                            <div class="col-md-12">
                                                <input type="email" placeholder="Alamat Email" class="form-control form-control-line" name="email" id="email" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" for="password">Password</label>
                                            <div class="col-md-12">
                                                <input type="password" placeholder="Minimal 8 Karakter" min="8" class="form-control form-control-line" name="password" id="password" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12" for="konfirmasi_password">Konfirmasi Password</label>
                                            <div class="col-md-12">
                                                <input type="password" placeholder="Konfirmasi Password" min="8" class="form-control form-control-line" name="konfirmasi_password" id="konfirmasi_password" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-sm-12" for="id_level">Pilih Level</label>
                                            <div class="col-sm-12">
                                                <select class="form-control form-control-line" name="id_level" id="id_level" required>
                                                    <option value="1">1: Administrator</option>
                                                    <option value="2">2: Operator</option>
                                                    <option value="3">3: Peminjam</option>
                                                </select>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <button type="submit" class="btn btn-success border-0 px-5" name="tambah">Tambah</button>
                                                <a href="index" class="btn btn-danger border-0">Batal</a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- Column -->
                    </div>
                </div>
        </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Reiznu Ahmad Tjandrida</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->
<?php include '../template/footer.php'; ?>