<?php
session_start();
require('functions.php');

if (isset($_POST["login"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $result = mysqli_query($conn, "SELECT * FROM petugas WHERE username = '$username'");

    if (mysqli_num_rows($result) === 1 ) {
        // Cek Password
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row["password"])) {
            // Set Session
            $_SESSION["login"] = true;

            if ($row["id_level"] == 1) {
                $_SESSION["level"] = $row["id_level"];
                $_SESSION["nama_level"] = "Administrator";
                $_SESSION["username"] = $row["username"];
            } elseif ($row["id_level"] == 2) {
                $_SESSION["level"] = $row["id_level"];
                $_SESSION["nama_level"] = "Operator";
                $_SESSION["username"] = $row["username"];
            } elseif ($row["id_level"] == 3) {
                $_SESSION["level"] = $row["id_level"];
                $_SESSION["nama_level"] = "Peminjam";
                $_SESSION["username"] = $row["username"];
            }
            $_SESSION['sukses'] = true;
            header("Location: dashboard/home/index");
            exit;
        }
    }

    $error = true;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Login</title>

  <link rel="shortcut icon" href="dashboard/assets/images/box.png" type="image/x-icon"/>
  <link href="https://fonts.googleapis.com/css?family=Karla:400,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="dashboard/assets/dist/css/material.min.css">
  <link rel="stylesheet" href="dashboard/assets/dist/css/bootstrap.min.css">
  <link href="dashboard/assets/dist/css/login.css" rel="stylesheet">
</head>

<body>
  <form action="" method="post">
    <main class="d-flex align-items-center min-vh-100 py-3 py-md-0">
      <div class="container">
        <div class="card login-card">
          <div class="row no-gutters">
            <div class="col-md-5">
              <img src="dashboard/assets/images/portfolio-2.jpg" alt="login" class="login-card-img img-fluid">
            </div>
            <div class="col-md-7">
              <div class="card-body">
                <div class="brand-wrapper">
                  <h1>LOGIN</h1>
                </div>
                <?php if (isset($error)) : ?>
                  <div class="alert alert-danger" role="alert">
                    Username atau Password Salah
                  </div>
                <?php endif; ?>
                <p class="login-card-description">Masuk Menggunakan Akun Anda</p>
                <form action="#!" method="post">
                  <div class="form-group">
                    <label for="username" class="sr-only">Username</label>
                    <input type="text" name="username" id="username" class="form-control" placeholder="Username" required autofocus>
                  </div>
                  <div class="form-group mb-4">
                    <label for="password" class="sr-only">Password</label>
                    <input type="password" name="password" id="password" class="form-control" placeholder="***********" required>
                  </div>
                  <div class="form-group">
                    <input name="login" id="login" class="btn btn-block login-btn mb-4" type="submit" value="Login">
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  </form>
</body>

</html>